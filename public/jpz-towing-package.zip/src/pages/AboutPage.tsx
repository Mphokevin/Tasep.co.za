import React from 'react';
import { PageId } from '../types';
import { JPZ_INFO, FLEET_VEHICLES, SOWETO_LANDMARKS, CLIENT_REVIEWS } from '../data/jpzData';
import { 
  AlertTriangle, Phone, ShieldCheck, Clock, 
  MapPin, Award, CheckCircle2, Heart, Users, Truck
} from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
  onOpenEmergency: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate, onOpenEmergency }) => {
  return (
    <div className="space-y-16 py-8 pb-20">
      {/* Hero Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-slate-950 text-white p-6 sm:p-12 border border-yellow-500/30 shadow-2xl">
          <div className="absolute inset-0 z-0">
            <img
              src="/assets/aistudio/IMG-20261029-WA0246_3e27129d.jpg"
              alt="JPZ Towing Rollback Truck"
              className="w-full h-full object-cover filter brightness-[0.25] contrast-125"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent" />
          </div>

          <div className="relative z-10 max-w-2xl space-y-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-400/20 text-yellow-400 text-xs font-black uppercase tracking-wider">
              About JPZ Towing Services
            </span>
            <h1 className="text-3xl sm:text-5xl font-black uppercase tracking-tight font-heading">
              Soweto's Most Trusted 24/7 Recovery Team
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              Born and operated in Soweto, JPZ Towing was founded on a simple, uncompromising promise: when a motorist is stranded, we get there fast, protect their vehicle, and treat them with honest respect.
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={onOpenEmergency}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-sm flex items-center gap-2 shadow-lg shadow-red-900/40 cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4 text-yellow-300" />
                <span>Request ASAP Tow</span>
              </button>
              <a
                href={`tel:${JPZ_INFO.primaryPhoneRaw}`}
                className="px-6 py-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-sm flex items-center gap-2 shadow-md"
              >
                <Phone className="w-4 h-4" />
                <span>Call {JPZ_INFO.primaryPhone}</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Origin & Core Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-black text-yellow-500 uppercase tracking-widest">
              Our Township Roots
            </span>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tight">
              Why Speed & Community Matter In Soweto
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Breaking down late at night on Chris Hani Road, the Golden Highway, or in deep residential pockets of Soweto can be stressful and dangerous. Standard corporate insurance dispatch centers often take 90 minutes to two hours to send an outsourced contractor.
            </p>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              JPZ Towing operates locally with dedicated rigs patrolling Pimville, Diepkloof, Orlando, Baragwanath, and Protea Glen around the clock. Because our drivers live and work in Soweto, we know every shortcut, bypass, and township landmark—reaching stranded drivers in an average of <strong>15 to 25 minutes</strong>.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <Clock className="w-5 h-5 text-yellow-500 mb-2" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">15-25m Soweto Arrival</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Staged at prime junctions for rapid deployment.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <ShieldCheck className="w-5 h-5 text-emerald-500 mb-2" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">Damage-Free Transport</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Underlift wheel-lift and flatbed rollback protection.</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-yellow-400/40 bg-black aspect-4/3">
              <img
                src="/assets/aistudio/IMG-20261029-WA0243_aaa4daf1.jpg"
                alt="JPZ Blue Nissan Tow Truck in Soweto"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-xs font-mono font-bold bg-yellow-400 text-slate-950 px-2 py-0.5 rounded">
                  JPZ Unit 1 • 116 JPZ GP
                </span>
                <p className="text-sm font-bold mt-1">
                  Custom Nissan Hardbody 16-Valve Wheel-Lift Rig in action
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet Overview Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-2 mb-10">
          <span className="text-xs font-black text-yellow-500 uppercase tracking-widest">
            Specialized Equipment
          </span>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">
            Our Purpose-Built Recovery Fleet
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Every vehicle in the JPZ fleet is custom-fitted with certified recovery rigging, heavy winches, and high-visibility safety strobe systems.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {FLEET_VEHICLES.map((vehicle) => (
            <div
              key={vehicle.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="relative h-48 bg-slate-950 overflow-hidden">
                  <img
                    src={vehicle.primaryImage}
                    alt={vehicle.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-black/70 px-2 py-0.5 rounded text-[11px] font-mono text-yellow-400 font-bold border border-yellow-400/40">
                    {vehicle.plate}
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <span className="text-[10px] font-black uppercase text-yellow-600 dark:text-yellow-400 tracking-wider">
                    {vehicle.type}
                  </span>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white leading-tight">
                    {vehicle.name}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {vehicle.description}
                  </p>

                  <div className="space-y-1.5 pt-2 text-xs border-t border-slate-100 dark:border-slate-800">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Payload:</span>
                      <span className="font-bold text-slate-900 dark:text-white">{vehicle.specs.capacity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Winch Rating:</span>
                      <span className="font-bold text-yellow-600 dark:text-yellow-400">{vehicle.specs.winchRating}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  onClick={onOpenEmergency}
                  className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-yellow-400 hover:text-slate-950 text-slate-900 dark:text-white text-xs font-bold transition-all cursor-pointer text-center"
                >
                  Request Dispatch
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Operational Standards & Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-yellow-500/30 shadow-xl">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-black text-yellow-400 uppercase tracking-widest">
              The JPZ Towing Code
            </span>
            <h3 className="text-2xl sm:text-3xl font-black uppercase">
              Our 4 Non-Negotiable Standards
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1 p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                <h4 className="font-bold text-sm text-yellow-400">1. Transparent Pricing Always</h4>
                <p className="text-xs text-slate-300">No predatory hook-fees or surprise kilometer inflations on the roadside. You receive the exact quotation before we hitch.</p>
              </div>
              <div className="space-y-1 p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                <h4 className="font-bold text-sm text-yellow-400">2. Customer Safety Priority</h4>
                <p className="text-xs text-slate-300">If you are in an unsafe location at night, our operator stays on the line with you until our tow truck is on scene with strobe lights.</p>
              </div>
              <div className="space-y-1 p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                <h4 className="font-bold text-sm text-yellow-400">3. Zero Secondary Damage</h4>
                <p className="text-xs text-slate-300">We treat your car like our own. Soft straps, wheel-lift brackets, and rubberized blocks ensure bumpers and steering racks remain pristine.</p>
              </div>
              <div className="space-y-1 p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                <h4 className="font-bold text-sm text-yellow-400">4. Insurance & Police Scene Integrity</h4>
                <p className="text-xs text-slate-300">Accident scene photos, incident numbers, and panel shop drops are fully documented and stamped for smooth claim processing.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
